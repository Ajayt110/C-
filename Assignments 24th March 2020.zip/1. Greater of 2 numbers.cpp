#include<iostream>
using namespace std;
int main()
{
int num1,num2;
cout<<"Enter 2 numbers:\n";
cin>>num1>>num2;
if(num1>num2)
cout<<"\nNumber "<<num1<<" is greater";
else 
cout<<"\nNumber "<<num2<<" is greater";
return 0;
}
