#include<iostream>
using namespace std;
int main()
{
	int a;
	cout<<"Enter a number to check is Even or Odd: ";
	cin>>a;
	if(a%2==0)
	cout<<"\n"<<a<<" is Even.\n";
	else
	cout<<"\n"<<a<<" is Odd.\n";
	return 0;
}
