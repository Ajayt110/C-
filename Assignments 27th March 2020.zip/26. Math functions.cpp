#include<iostream>
#include<math.h>
using namespace std;
main()
{
	int x=5,y=8,z=225,l=-10;
	float a=3.2,b=4.8;
	cout<<"\n"<<x<<" raised to power "<<y<<" is: "<<pow(x,y);
	cout<<"\nSquare root of "<<z<<" is: "<<sqrt(z);
	cout<<"\nUpper limit of "<<a<<" is: "<<ceil(a);
	cout<<"\nLower limit of "<<b<<" is: "<<floor(a);
	cout<<"\nAbsolute value of "<<l<<" is: "<<abs(l);
}
